from django.urls import path
from . import views
urlpatterns = [
path('add_student/', views.add_student, name='add_student'),
path('add_course/', views.add_course, name='add_course'),
path('register/', views.register_student, name='register_student'),
path('courses/', views.course_registration, name='course_registration'),
path('students_list/<int:course_id>/', views.students_list,name='students_list'),
path('project_list/', views.project_list, name='project_list'),
path('add_project/', views.add_project, name='add_project'),
path('students/', views.StudentListView.as_view(), name='student_list'),
path('student//', views.StudentDetailView.as_view(),name='student_detail'),
]