from django import forms
class StudentRegistrationForm(forms.Form):
    name = forms.CharField(label='Full Name', max_length=100)
    email = forms.EmailField(label='Email')
    course = forms.CharField(label='Course', max_length=100)    