from django.http import JsonResponse
from pg1.models import Course
from django.shortcuts import render

def search_courses(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        query = request.GET.get('query', None)
        if query:
            # Perform the search based on the query parameter
            courses = Course.objects.filter(students__name__icontains=query)
            # Create a list of course names
            course_names = [{'name': course.name, 'course_id': course.course_id} for course in courses]
            # Return the list of course names as JSON response
            return JsonResponse({'courses': course_names})
        else:
            return JsonResponse({'error': 'No query parameter provided'})
    else:
        # Optionally, handle non-AJAX requests here
        return render(request, 'pg1/search.html')
