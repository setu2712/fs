from .models import Student
from django import forms
from .models import Course
from .models import Project
class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['topic', 'languages_used', 'duration']
class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['name', 'course_id']
class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['name', 'date_of_birth', 'email']