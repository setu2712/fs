from django.urls import path
from . import views
urlpatterns = [
path('fruits_and_students/', views.fruits_and_students, name='fruits_and_students'),
]