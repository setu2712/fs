from django.shortcuts import render
def home(request):
    return render(request, 'pg1/home.html')
def about_us(request):
    return render(request, 'pg1/about_us.html')
def contact_us(request):
    return render(request, 'pg1/contact_us.html')