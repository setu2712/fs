from django.urls import path
from . import views
urlpatterns = [
path('offset_date/', views.offset_time, name='offset_time'),
]