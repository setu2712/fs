from django.shortcuts import render
from datetime import datetime, timedelta
def offset_time(request):
    current_time = datetime.now()
    offset_time_forward = current_time + timedelta(hours=4)
    offset_time_backward = current_time - timedelta(hours=4)
    return render(request, 'pg1/offset_date.html', {
    'current_time': current_time,

        'offset_time_forward': offset_time_forward,
        'offset_time_backward': offset_time_backward,

})
    
    
