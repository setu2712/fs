from django.contrib import admin
from django.urls import path,include 
#from . import views
urlpatterns = [
path('admin/', admin.site.urls),
path('pg1/', include('pg1.urls')), # Include your app's URLs
]