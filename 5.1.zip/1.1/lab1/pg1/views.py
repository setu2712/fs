from django.shortcuts import render
from django.http import JsonResponse
from .forms import StudentRegistrationForm

def register_student(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            return JsonResponse({"success": True, "message": "Student registered successfully!"})
        else:
            return JsonResponse({"success": False, "errors": form.errors})
    else:
        form = StudentRegistrationForm()
        return render(request, 'pg1/register.html', {'form': form})
